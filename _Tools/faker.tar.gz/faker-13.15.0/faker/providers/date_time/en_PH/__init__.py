from .. import Provider as DateTimeProvider


class Provider(DateTimeProvider):
    """No difference from default DateTimeProvider"""

    pass
